create trigger T_ETC_SYS_USER_ID
  before insert
  on T_ETC_SYS_USER
  for each row
  when (new.USER_ID is null)
begin
  select T_ETC_SYS_USER_USER_ID.nextval into:new.USER_ID from dual;
end;
/

