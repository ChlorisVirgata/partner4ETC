create trigger T_ETC_SYS_ROLE_ROLE_ID_TRIG
  before insert
  on T_ETC_SYS_ROLE
  for each row
  when (new.role_id is null)
begin
  select T_ETC_SYS_ROLE_ROLE_ID_SEQ.nextval into:new.role_id from dual;
end;
/

