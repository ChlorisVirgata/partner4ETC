create trigger T_ETC_SYS_MENU_MENU_ID
  before insert
  on T_ETC_SYS_MENU
  for each row
  when (new.MENU_ID is null)
begin
  select T_ETC_SYS_MENU_MENU.nextval into:new.MENU_ID from dual;
end;
/

